# Material del curso introductorio de *machine learning* 

En este repositorio vamos a ir agregando el material que se utilizó para el curso de introducción al aprendizaje máquina.

## Material

### Primer día

1. ¿Que es la ciencia de datos?
2. Herrmanientas para ciencia de datos: `python`, `numpy`, `pandas` y `Jupyter`
3. ¿Que es el aprendizaje máquina?
4. Herramienta para aprendizaje máquina `scikit-learn`



